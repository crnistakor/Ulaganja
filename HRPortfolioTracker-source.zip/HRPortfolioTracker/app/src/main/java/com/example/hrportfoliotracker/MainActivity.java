package com.example.hrportfoliotracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.util.*;
import java.text.NumberFormat;

public class MainActivity extends Activity {
    private static final String HOME = "https://hrportfolio.hr/";
    private static final String PREFS = "tracker";
    private LinearLayout root, content;
    private TextView status, summary;
    private String mode = "Funds";
    private final ArrayList<Asset> funds = new ArrayList<>(), shares = new ArrayList<>();
    private final ArrayList<Holding> holdings = new ArrayList<>();
    private final NumberFormat eur = NumberFormat.getCurrencyInstance(Locale.GERMANY);

    static class Asset {
        String name, symbol, type, date="", currency="EUR";
        double price=Double.NaN, daily=Double.NaN, siteYtd=Double.NaN;
        Asset(String n, String s, String t) { name=n; symbol=s; type=t; }
    }
    static class Holding {
        String name, symbol, type;
        double quantity, average;
        Holding(String n,String s,String t,double q,double a){name=n;symbol=s;type=t;quantity=q;average=a;}
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); loadHoldings(); buildUi(); render(); refreshData();
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s, int size, boolean bold) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(0xff18332c);
        if(bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); v.setPadding(dp(2),dp(4),dp(2),dp(4)); return v;
    }
    private void buildUi(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(20)); root.setBackgroundColor(0xfff5f7f6); scroll.addView(root); setContentView(scroll);
        TextView title=text("HRPortfolio Tracker",25,true); title.setTextColor(0xff123d32); root.addView(title);
        root.addView(text("Funds & Croatian shares · personal performance",13,false));
        summary=text("Portfolio value: —     Profit/loss: —",15,true); summary.setPadding(0,dp(14),0,dp(14)); root.addView(summary);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button refresh=new Button(this); refresh.setText("Refresh data"); refresh.setOnClickListener(v->refreshData()); actions.addView(refresh,new LinearLayout.LayoutParams(0,dp(48),1));
        Button add=new Button(this); add.setText("Add holding"); add.setOnClickListener(v->addHoldingDialog()); actions.addView(add,new LinearLayout.LayoutParams(0,dp(48),1)); root.addView(actions);
        status=text("Loading HRPortfolio…",12,false); root.addView(status);
        LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
        Button fb=new Button(this); fb.setText("Funds"); fb.setOnClickListener(v->{mode="Funds";render();}); tabs.addView(fb,new LinearLayout.LayoutParams(0,dp(48),1));
        Button sb=new Button(this); sb.setText("Shares"); sb.setOnClickListener(v->{mode="Shares";render();}); tabs.addView(sb,new LinearLayout.LayoutParams(0,dp(48),1));
        Button hb=new Button(this); hb.setText("My holdings"); hb.setOnClickListener(v->{mode="Holdings";render();}); tabs.addView(hb,new LinearLayout.LayoutParams(0,dp(48),1)); root.addView(tabs);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); root.addView(content);
        TextView foot=text("Source: hrportfolio.hr. Data is indicative and may be delayed. Month-to-date uses the first price captured in the current month; no historical backfill.",11,false); foot.setPadding(0,dp(18),0,dp(8)); root.addView(foot);
    }
    private void refreshData(){
        status.setText("Fetching public data from hrportfolio.hr…");
        new Thread(()->{
            String error=null;
            try {
                Document doc=Jsoup.connect(HOME).userAgent("Mozilla/5.0 HRPortfolioTracker/0.1 (personal use)").timeout(20000).get();
                parseTables(doc);
                runOnUiThread(()->{saveMonthBaselines(); status.setText("Updated from hrportfolio.hr · "+new Date()); render();});
            } catch(Exception e){ error=e.getClass().getSimpleName()+": "+e.getMessage(); final String msg=error; runOnUiThread(()->{status.setText("Could not refresh live data. Check connection or site changes. "+msg); render();}); }
        }).start();
    }
    private void parseTables(Document doc){
        ArrayList<Asset> nf=new ArrayList<>(), ns=new ArrayList<>();
        // HRPortfolio's public homepage contains a funds price table and a ZSE shares table.
        for(Element table:doc.select("table")){
            String context=table.parent()!=null?table.parent().text():"";
            String nearby=table.text();
            boolean shareTable=nearby.contains("Promet") && (nearby.contains("ZSE") || nearby.contains("Zadnja") || nearby.contains("Dionica"));
            for(Element tr:table.select("tr")){
                Elements cells=tr.select("th,td"); if(cells.size()<3) continue;
                String name=cells.get(0).text().trim();
                if(name.isEmpty() || name.length()>100 || name.equalsIgnoreCase("Fond") || name.equalsIgnoreCase("Dionica")) continue;
                String all=tr.text();
                if(shareTable || all.matches(".*\\b[A-Z0-9]{2,6}\\b.*") && cells.size()<=5 && (all.contains("€")||all.contains(","))){
                    String symbol=name;
                    double price=Double.NaN, daily=Double.NaN;
                    ArrayList<Double> nums=new ArrayList<>(); for(int i=1;i<cells.size();i++){double x=parseNumber(cells.get(i).text());if(!Double.isNaN(x))nums.add(x);}
                    if(nums.size()>=1) price=nums.get(0); if(nums.size()>=2) daily=nums.get(1);
                    if(price>0 && symbol.matches("[A-Z0-9]{2,8}")){Asset a=new Asset(name,symbol,"Share");a.price=price;a.daily=daily;a.currency="EUR";ns.add(a);} 
                } else {
                    // Fund table columns generally include name, date, unit price, currency, daily %, YTD %.
                    String symbol=name; double price=Double.NaN,daily=Double.NaN,ytd=Double.NaN; String date="",cur="EUR";
                    if(cells.size()>=3){ date=cells.get(1).text().trim(); price=parseNumber(cells.get(2).text()); }
                    for(int i=3;i<cells.size();i++){
                        String val=cells.get(i).text().trim();
                        if(val.equals("€")||val.equals("$")||val.equals("USD")){cur=val.equals("$")?"USD":val;}
                        double n=parseNumber(val);
                        if(!Double.isNaN(n)){if(Double.isNaN(daily))daily=n;else if(Double.isNaN(ytd))ytd=n;}
                    }
                    if(price>0){Asset a=new Asset(name,symbol,"Fund");a.price=price;a.daily=daily;a.siteYtd=ytd;a.date=date;a.currency=cur;nf.add(a);}
                }
            }
        }
        synchronized(funds){funds.clear();funds.addAll(unique(nf));} synchronized(shares){shares.clear();shares.addAll(unique(ns));}
    }
    private ArrayList<Asset> unique(ArrayList<Asset> input){LinkedHashMap<String,Asset> m=new LinkedHashMap<>();for(Asset a:input)m.put(a.name,a);return new ArrayList<>(m.values());}
    private double parseNumber(String raw){
        if(raw==null)return Double.NaN; String s=raw.replace("\u00a0","").replace(" ","").replace("%","").replace("€","").replace("$","");
        // HRPortfolio may render duplicate machine-readable and localized numbers; use the final token.
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("[-+]?\\d[\\d.,]*").matcher(s); String last=null; while(m.find())last=m.group(); if(last==null)return Double.NaN;
        if(last.contains(",")&&last.contains(".")){if(last.lastIndexOf(',')>last.lastIndexOf('.'))last=last.replace(".","").replace(',','.');else last=last.replace(",","");}
        else if(last.contains(",")){String[] p=last.split(","); if(p.length==2&&p[1].length()<=2)last=last.replace(',','.');else last=last.replace(",","");}
        try{return Double.parseDouble(last);}catch(Exception e){return Double.NaN;}
    }
    private String baselineKey(Asset a){return "month_"+a.type+"_"+a.name+"_"+java.time.YearMonth.now();}
    private void saveMonthBaselines(){android.content.SharedPreferences p=getSharedPreferences(PREFS,0);android.content.SharedPreferences.Editor e=p.edit();for(Asset a:allAssets()){String k=baselineKey(a);if(!p.contains(k))e.putFloat(k,(float)a.price);}e.apply();}
    private double monthly(Asset a){return getSharedPreferences(PREFS,0).getFloat(baselineKey(a),(float)Double.NaN);}
    private ArrayList<Asset> allAssets(){ArrayList<Asset> x=new ArrayList<>();x.addAll(funds);x.addAll(shares);return x;}
    private void render(){if(content==null)return;content.removeAllViews();updateSummary();
        if(mode.equals("Holdings")){renderHoldings();return;}
        ArrayList<Asset> list=mode.equals("Funds")?funds:shares;
        content.addView(text(mode+" from HRPortfolio",18,true));
        if(list.isEmpty()){content.addView(text("No parsed market rows yet. The website may have changed its HTML; see README for limitations.",14,false));return;}
        int shown=0; for(Asset a:list){if(shown++>=120)break;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackgroundColor(0xffffffff);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(5),0,dp(5));content.addView(card,cp);
            TextView n=text(a.name,15,true);card.addView(n);String price=Double.isNaN(a.price)?"—":String.format(Locale.US,"%.4f %s",a.price,a.currency);card.addView(text("Price: "+price+(a.date.isEmpty()?"":" · Date: "+a.date),13,false));
            String d=Double.isNaN(a.daily)?"n/a":String.format(Locale.US,"%+.2f%%",a.daily);double base=monthly(a);String m=Float.isNaN((float)base)||base<=0?"collecting baseline":String.format(Locale.US,"%+.2f%%",(a.price/base-1)*100);
            card.addView(text("Daily: "+d+"     Month-to-date: "+m,13,true));
            Button add=new Button(this);add.setText("Track this asset");add.setOnClickListener(v->showHoldingEditor(a.name,a.symbol,a.type));card.addView(add);
        }
    }
    private void updateSummary(){double value=0,cost=0;for(Holding h:holdings){Asset a=findAsset(h);if(a!=null&&a.price>0){value+=h.quantity*a.price;cost+=h.quantity*h.average;}}summary.setText("Holdings value: "+eur.format(value)+"    Profit/loss: "+eur.format(value-cost));}
    private Asset findAsset(Holding h){ArrayList<Asset> l=h.type.equals("Fund")?funds:shares;for(Asset a:l)if(a.name.equals(h.name)||a.symbol.equals(h.symbol))return a;return null;}
    private void renderHoldings(){content.addView(text("My holdings",18,true));if(holdings.isEmpty()){content.addView(text("No holdings yet. Browse Funds or Shares and tap Track this asset, or use Add holding.",14,false));return;}for(Holding h:new ArrayList<>(holdings)){Asset a=findAsset(h);double price=a==null?Double.NaN:a.price;double value=Double.isNaN(price)?Double.NaN:price*h.quantity;double pl=Double.isNaN(value)?Double.NaN:value-h.quantity*h.average;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(8),dp(12),dp(8));card.setBackgroundColor(0xffffffff);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));content.addView(card,lp);card.addView(text(h.name+" ("+h.type+")",15,true));card.addView(text("Quantity: "+h.quantity+" · Average cost: "+eur.format(h.average),13,false));card.addView(text("Market value: "+(Double.isNaN(value)?"unavailable":eur.format(value))+" · P/L: "+(Double.isNaN(pl)?"unavailable":eur.format(pl)),13,true));Button edit=new Button(this);edit.setText("Edit / remove");edit.setOnClickListener(v->editHolding(h));card.addView(edit);}}
    private void addHoldingDialog(){new AlertDialog.Builder(this).setTitle("Add holding").setItems(new String[]{"Find from funds", "Find from shares", "Enter manually"},(d,w)->{if(w==0){mode="Funds";render();status.setText("Tap Track this asset next to a fund.");}else if(w==1){mode="Shares";render();status.setText("Tap Track this asset next to a share.");}else showHoldingEditor("","","Share");}).show();}
    private void showHoldingEditor(String name,String symbol,String type){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(4),dp(20),0);EditText nm=field("Asset name",name), sy=field("Ticker / symbol (optional)",symbol), qt=field("Quantity / units", "1"), av=field("Average purchase price per unit (EUR)","0");box.addView(nm);box.addView(sy);Spinner sp=new Spinner(this);String[] types={"Share","Fund"};sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,types));sp.setSelection(type.equals("Fund")?1:0);box.addView(sp);box.addView(qt);box.addView(av);new AlertDialog.Builder(this).setTitle("Track holding").setView(box).setPositiveButton("Save",(d,w)->{try{Holding h=new Holding(nm.getText().toString().trim(),sy.getText().toString().trim(),sp.getSelectedItem().toString(),Double.parseDouble(qt.getText().toString().replace(',','.')),Double.parseDouble(av.getText().toString().replace(',','.')));if(h.name.isEmpty()||h.quantity<0||h.average<0)throw new Exception();holdings.removeIf(old->old.name.equals(h.name)&&old.type.equals(h.type));holdings.add(h);saveHoldings();mode="Holdings";render();}catch(Exception e){Toast.makeText(this,"Please enter a name and valid non-negative numbers.",Toast.LENGTH_LONG).show();}}).setNegativeButton("Cancel",null).show();}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(value);return e;}
    private void editHolding(Holding h){new AlertDialog.Builder(this).setTitle(h.name).setItems(new String[]{"Edit", "Remove"},(d,w)->{if(w==0)showHoldingEditor(h.name,h.symbol,h.type);else{holdings.remove(h);saveHoldings();render();}}).show();}
    private void saveHoldings(){JSONArray arr=new JSONArray();try{for(Holding h:holdings){JSONObject o=new JSONObject();o.put("name",h.name);o.put("symbol",h.symbol);o.put("type",h.type);o.put("quantity",h.quantity);o.put("average",h.average);arr.put(o);}}catch(Exception ignored){}getSharedPreferences(PREFS,0).edit().putString("holdings",arr.toString()).apply();}
    private void loadHoldings(){try{JSONArray a=new JSONArray(getSharedPreferences(PREFS,0).getString("holdings","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);holdings.add(new Holding(o.optString("name"),o.optString("symbol"),o.optString("type","Share"),o.optDouble("quantity"),o.optDouble("average")));}}catch(Exception ignored){}}
}
