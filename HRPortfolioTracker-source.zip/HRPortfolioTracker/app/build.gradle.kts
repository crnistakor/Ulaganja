plugins { id("com.android.application") }

android {
    namespace = "com.example.hrportfoliotracker"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.hrportfoliotracker"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    implementation("org.jsoup:jsoup:1.18.3")
}
