# HRPortfolio Tracker (Android)

A small native Android starter app that reads the public HRPortfolio homepage, lists fund and share rows it can parse, and lets you record your own holdings locally on the phone.

## Features in this first implementation

- English interface.
- Refresh public market rows from `https://hrportfolio.hr/`.
- Funds and Croatian shares tabs.
- Add/track a holding with asset name, optional ticker, type, quantity and average purchase price.
- Local holdings storage using Android SharedPreferences (no login or holdings data sent to HRPortfolio).
- Estimated current holdings value and profit/loss using the latest parsed price.
- Month-to-date change calculated from the first observed price for that asset in the current month, saved locally. It does not backfill a month of historical data; first install starts the baseline at the first refresh.

## Important limitations

1. The initial source check found public fund and share tables on HRPortfolio, but did not verify a documented public API or permission for automated data retrieval. This prototype reads the public HTML homepage and can break if its markup changes or access is restricted. Contact HRPortfolio for an official data feed / permission before distributing the app.
2. Parsing is heuristic and needs validation against real devices and the live page. Confirm the displayed price and percentage against the source before relying on calculations. This is a prototype, not a financial service.
3. Share/fund currencies may differ. The current simple personal P/L summary assumes EUR for average purchase price and does not perform currency conversion. Do not use it for assets priced in other currencies without extending the currency model.
4. It only estimates price-based profit/loss. It does not include commissions, taxes, dividends/distributions, fund entry/exit fees, corporate actions or cash flows.
5. It does not sign in to HRPortfolio or import the account's registered-user watchlist.

## Build the APK

The current work environment does not have the Android SDK or Gradle installed, so an APK could not be compiled and verified here. The full Android Studio project is provided.

1. Install Android Studio with Android SDK Platform 35 and a compatible JDK (JDK 17 is recommended for Android Gradle Plugin 8.7.x).
2. Open this `HRPortfolioTracker` folder in Android Studio and allow Gradle sync to finish.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).
5. Install the debug APK on your phone and check that parsed prices exactly match HRPortfolio before adding real holdings.

## Project structure

- `app/src/main/java/com/example/hrportfoliotracker/MainActivity.java` — UI, retrieval, parsing and holdings calculations.
- `app/src/main/AndroidManifest.xml` — Android app and internet permission.
- `app/build.gradle.kts` — Android plugin and Jsoup HTML parser dependency.

## Data attribution

Market data source: [hrportfolio.hr](https://www.hrportfolio.hr/). The website asks that it be credited when its charts/content are used. This app is an independent prototype and is not affiliated with HRPortfolio.
